# Campus Access: corrected policy evidence comparison

Reviewed October 15, 2026. Open **index.html** after extracting the ZIP. All pages run locally; no server or package installation is needed. The pricing/request page is retained from the supplied project.

## What changed

- Added a specific barrier explanation and a more accessible alternative to every one of the 71 scored findings, in profiles and both complete evidence audits. This explanation update changes no ratings, deductions, published policy facts, or sources.
- Recalculated all 22 star ratings on 85 points across six policy categories. Removed HIU’s former five-point physical deduction. The earlier scoring/source corrections remain documented.
- Applied academic-renewal scope consistently; housing-only renewal stays as context.
- Withheld coordination penalties supported only by recommended actions.
- Added supported omitted appeal, communication, and recent-assessment findings.
- Updated Hartford International to its current 2026–2027 handbook.
- Kept source conflicts, limitations, and removed deductions visible.
- Generated every audit page from the same canonical data.

## Ratings and arithmetic

**Every college displays a provisional policy-burden rating out of five stars.**

Each college’s rating is (85 − recorded deductions) / 85 × 5, rounded half up to one decimal. Stars and the numeric value appear on the college cards, in profiles, and in the audits. Missing information is not penalized; evidence coverage and qualifications remain visible. This is a provisional policy-burden rating rather than certification of overall campus accessibility. The six retained category caps total 85; physical and digital accessibility are excluded from both the available points and the deductions; the weights are editorial and have not been independently validated as overall campus accessibility quality.

There are 71 recorded scoring findings. Finding a requirement does not complete its category assessment. The data distinguishes categories with evidence from completed reviews and records a confirmed zero for Western’s largely automatic academic-renewal rule.

## Understanding the explanations

Each scored finding separates the published requirement and source qualifications from **Why points were deducted** and **A more accessible approach**. The latter two are editorial explanations and recommendations, not additional policy claims or findings about actual outcomes. Suggested improvements include staff scheduling known exams from a syllabus with student consent, and continuation of approved supports for stable or long-term disabilities with an easy course-specific opt-in. Student choice about disclosure and changes in needs remain part of those recommendations.

## Sources

All 158 original inventory URLs were attempted with the research tool, plus five refreshed/added official documents or pages. Of 163 records, 149 returned readable content without a retrieval flag; 14 have failed, insufficient, or intermittent retrieval. The current HIU handbook was readable through its official embedded link but failed a separate direct open; its handbook landing page is provided. This is not a direct HTTP uptime test or a guarantee of reader access. Retrieval problems are visibly flagged. Current indexed official UConn text is distinguished from directly retrieved pages. Background links, historical editions, and mirrors do not independently validate a score, and no six-link quota is presented as certification.

## Files

- index.html: original visual structure with corrected evidence-led cards and profiles.
- rubric.html and rubric-data.json: six retained category weights, an 85-point maximum, and explicit evidence/scope rules.
- audit.html: all 22 calculation and category breakdowns.
- administrator-proof.html: claim sources, qualifications, and administrator questions.
- verification-review.html and change-log.json: all-college reconciliation and correction decisions.
- six-source-audit.html: source roles and retrieval review; filename retained for existing links.
- research-cautions.html: unresolved matters and qualifications.
- rating-data.json: canonical college evidence and deductions; provisional five-star-scale ratings are populated for all 22 colleges; the independent comparable-accessibility field remains null.
- official-evidence-sources.json and official-source-inventory.csv: matching source inventories.
- evidence-coverage.csv: all 132 scored college/category rows.
- college-ratings.csv: all 22 displayed ratings and corrected deduction totals.
- source-checks.json: retrieval records, separate from content/claim validation.
- tools/rebuild.py: regenerate the pages and CSVs from the canonical data using Python 3.

## Boundaries

Published policy does not prove every actual accommodation experience, physical route, digital tool, staff action, or legal conclusion. The remaining assessment work is visible; the displayed numerical ratings are the reproducible result of the stated editorial policy-burden rubric.
