#!/usr/bin/env python3
"""Rebuild the offline pages from the canonical JSON, using only Python's standard library."""
from pathlib import Path
import csv
import html
import json

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'rating-data.json').read_text())
MODEL = json.loads((ROOT / 'rubric-data.json').read_text())
CHANGES = json.loads((ROOT / 'change-log.json').read_text())
CHECKS = json.loads((ROOT / 'source-checks.json').read_text())
DATE = 'October 15, 2026'
BASE_CSS = (ROOT / 'site.css').read_text()
EXTRA_CSS = '''
.star-meter{display:inline-block;position:relative;white-space:nowrap;letter-spacing:1px;line-height:1.1;font-size:15px;color:#b7bfb9;margin:5px 0}.star-fill{position:absolute;left:0;top:0;white-space:nowrap;overflow:hidden;color:#b67b09;height:100%}.card-rating .rating-qualifier{font-size:10px;line-height:1.35;color:#6e592b;margin:3px 0}.rating-box .star-meter{font-size:19px}.card-rating .rating-numeric{font-size:26px;line-height:1.1}
.barrier-reason{margin-top:14px;padding:12px 14px;border-left:3px solid #547861;border-radius:0 8px 8px 0;background:#f2f7f1}.barrier-reason p{line-height:1.65}.barrier-reason p:last-child{margin-bottom:0}.rationale-note{font-size:12px;line-height:1.65;color:#4d6254;margin:12px 0}
.audit-wrap{max-width:1040px;margin:0 auto;padding:24px}.audit-wrap h1{font-size:clamp(27px,4vw,39px);line-height:1.15;letter-spacing:-.035em}.audit-wrap h2{font-size:24px;letter-spacing:-.025em}.audit-wrap h3{font-size:17px}.lede{color:#4e5e55;max-width:850px}.audit-card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:20px;margin:18px 0;scroll-margin-top:20px}.audit-card p{line-height:1.65}.audit-nav{display:flex;gap:8px 18px;flex-wrap:wrap;font-size:13px}.table-scroll{overflow:auto;margin:15px 0}table{border-collapse:collapse;width:100%;background:#fff;font-size:13px}th,td{text-align:left;vertical-align:top;border:1px solid #dce5df;padding:10px 12px}th{background:#edf4ef;font-weight:800}.audit-card details{margin:10px 0}summary{cursor:pointer;font-weight:750;line-height:1.5}details.calculation{border:1px solid #d9e1db;border-radius:10px;padding:12px 14px;margin:16px 0;background:#fcfdfb}.calculation p{font-size:13px;color:#4b5e51;line-height:1.7}.rating-pending{font-size:15px;line-height:1.2;color:#775b20;font-weight:850}.rating-box .pending-label{font-size:19px;letter-spacing:-.015em;line-height:1.2;color:#775b20}.rating-box.pending{min-width:135px;max-width:180px}.card-rating{min-width:112px;max-width:150px}.recorded-points{font-size:12px;font-weight:800;color:#4b6051;margin-top:7px}.chip{display:inline-block;font-size:10px;font-weight:800;border-radius:6px;padding:3px 6px;background:#edf4ef;color:#31563f;margin:3px 4px 3px 0}.chip.warn{background:#fff1d9;color:#795315}.chip.neutral{background:#f0f2f0;color:#566259}.source-status{font-size:11px;color:#5d6e60;line-height:1.5}.source-status.warn{color:#855719;font-weight:750}.source-card.unavailable{background:#fffaf0;border-color:#dfc995}.source-url{display:block;font-size:11px;overflow-wrap:anywhere;margin:7px 0}.source-role{font-size:11px;color:#516154}.excluded{border-left:3px solid #b6bfb6;padding:8px 12px;margin:12px 0;background:#f7f9f6}.excluded p{font-size:12px;color:#536457}.evidence-legend{font-size:12px;line-height:1.65;color:#5d6d61}.note-list{padding-left:20px}.note-list li{margin:9px 0}.questions{background:#f5f8f3;border-radius:10px;padding:12px 16px;font-size:13px;line-height:1.65}.rubric-fact.zero{background:#f5faf6}.method-note{font-size:12px;color:#5c6e60}.source-grid{margin-top:12px}a:focus-visible,button:focus-visible,summary:focus-visible{outline:3px solid #37765a;outline-offset:3px}.top-inner{flex-wrap:wrap;padding-top:12px;padding-bottom:12px}.audit-wrap code{overflow-wrap:anywhere}.rubric-category-head span{white-space:normal;text-align:right}.rubric-category-head{align-items:flex-start}.no-js{padding:15px;background:#fff5db}.source-card strong{line-height:1.45}
@media(max-width:560px){.audit-wrap{padding:17px 14px}.audit-card{padding:15px}.audit-nav{gap:7px 12px}.card-rating{max-width:122px}.rating-box.pending{min-width:100px}.rating-box .pending-label{font-size:16px}.detail-top{grid-template-columns:1fr}.detail-top .rating-box{max-width:none;display:block}.audit-wrap table{font-size:12px}th,td{padding:8px}.hero-stats .stat{min-width:calc(50% - 5px)}}
'''
CSS = BASE_CSS + EXTRA_CSS

def e(x):
    return html.escape(str(x), quote=True)

def link(url, label='Official source'):
    return f'<a href="{e(url)}" target="_blank" rel="noopener noreferrer">{e(label)} ↗</a>'

def links(urls):
    return ' · '.join(link(u, f'Official source {i+1}') for i, u in enumerate(urls))

NAV = '''<nav class="audit-nav" aria-label="Evidence pages"><a href="index.html">College comparison</a><a href="rubric.html">Rubric</a><a href="audit.html">Calculations</a><a href="administrator-proof.html">Policy evidence</a><a href="verification-review.html">Corrections</a><a href="six-source-audit.html">Source inventory</a><a href="research-cautions.html">Open questions</a></nav>'''

def page(filename, title, body):
    text = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)} · Campus Access</title><style>{CSS}</style></head><body><main class="audit-wrap">{NAV}<h1>{e(title)}</h1>{body}<footer class="footer"><p>Campus Access · {DATE} · Published policies; incomplete comparative assessment.</p></footer></main></body></html>'''
    (ROOT / filename).write_text(text)

def calculation(c):
    return f'''<details class="calculation"><summary>How this rating is calculated</summary><p>85 − {c['deductions']} recorded deduction points = {c['remaining_points']}/85. Dividing by 85 and multiplying by 5 gives <b>{c['calculation_only_stars']:.1f}/5</b>, rounded to one decimal using half-up rounding.</p><p>This provisional policy-burden rating uses the recorded deductions under the same editorial rubric. Missing information is not penalized, so evidence coverage and the stated qualifications should be read alongside the stars.</p></details>'''

def finding(it):
    return f'''<div class="rubric-fact"><h4>{e(it['title'])} (−{it['points']})</h4><p><b>Published policy:</b> {e(it['fact'])}</p><p><b>Scope and qualifications:</b> {e(it['qualification'])}</p><p class="tiny">{e(it['verification_scope'])}</p><div>{links(it['links'])}</div><div class="barrier-reason"><p><b>Why points were deducted:</b> {e(it['barrier_explanation'])}</p><p><b>A more accessible approach:</b> {e(it['more_accessible_approach'])}</p></div></div>'''

def observation(it):
    label = 'Documented zero under this criterion' if it['status'] == 'documented_zero' else 'Documented issue — deduction unresolved'
    return f'''<div class="rubric-fact zero"><h4>{e(it['title'])}</h4><p><b>{label}:</b> {e(it['fact'])}</p><p>{e(it['qualification'])}</p><div>{links(it['links'])}</div></div>'''

def categories(c):
    parts = []
    for k in c['categories']:
        status = f'−{k["deducted"]} recorded points' if k['items'] else '0 counted; assessment open'
        if k['evidence_status'] == 'documented_zero':
            status = '0 — automatic academic renewal'
        body = ''.join(finding(i) for i in k['items']) + ''.join(observation(i) for i in k['observations'])
        if not body:
            body = '<div class="rubric-empty">No specific scored requirement has been established here. This category remains unresolved; it has not been verified barrier-free.</div>'
        if not k['review_complete'] and k['items']:
            body += '<p class="rubric-empty">These findings do not complete the category assessment. Other applicable rules, exceptions, and student/campus scopes need comparable review.</p>'
        parts.append(f'<section class="rubric-category" data-category="{e(k["id"])}"><div class="rubric-category-head"><strong>{e(k["name"])}</strong><span>{status}</span></div>{body}</section>')
    return '<div class="rubric-grid">' + ''.join(parts) + '</div>'

def exclusions(c):
    if not c.get('excluded_findings'):
        return ''
    body = ''.join(f'<div class="excluded"><b>{e(i["title"])}</b><p>Previous deduction: {i["previous_points"]} points. Current deduction: 0.</p><p>{e(i["decision"])}</p><div>{links(i["links"])}</div></div>' for i in c['excluded_findings'])
    return '<details><summary>Removed or withheld deductions</summary>' + body + '</details>'

def notes(c):
    return ''.join(f'<div class="coverage-note"><b>{e(n["title"])}:</b> {e(n["detail"])}<div>{links(n["links"])}</div></div>' for n in c.get('review_notes', []))

ROLES = {'supports_deduction': 'Supports a recorded scoring finding', 'policy': 'Additional policy or policy pointer', 'context': 'Background context only', 'historical': 'Historical corroboration; not current-policy proof', 'duplicate': 'Duplicate edition or mirror; not independent evidence'}
STATUS = {'retrieved': 'Readable content returned by the research tool', 'retrieval_failed': 'Retrieval failed — reader access not confirmed', 'intermittent': 'Readable through the official embedded link; separate direct retrieval failed', 'insufficient_text': 'Insufficient readable content — not verified', 'no_usable_result': 'No usable result — not verified', 'not_checked': 'Not checked in this pass'}

def source_card(s):
    st = s['retrieval']['retrieval_status']
    warn = st != 'retrieved'
    indexed = ' Official indexed text was reviewed; direct access remains unconfirmed.' if s['retrieval'].get('indexed_official_content_reviewed') else ''
    superseded = f'<p class="source-status warn">{e(s["superseded_for"])}</p>' if s.get('superseded_for') else ''
    return f'''<div class="source-card {'unavailable' if warn else ''}"><strong>{link(s['url'], s['title'])}</strong><span class="source-role">{ROLES[s['kind']]}</span><span class="source-status {'warn' if warn else ''}">{STATUS[st]}.{indexed}</span>{superseded}</div>'''

def inventory(c):
    primary = [s for s in c['expanded_sources'] if s['used_for_scoring'] or s['used_for_observation']]
    rest = [s for s in c['expanded_sources'] if s not in primary]
    return '<div class="source-grid">' + ''.join(source_card(s) for s in primary) + '</div><details><summary>Additional policy, background, and historical links</summary><div class="source-grid">' + ''.join(source_card(s) for s in rest) + '</div></details>'

rating_note = '<p class="notice"><b>Policy-burden ratings out of five.</b> Every college is rated using (85 − recorded deductions) ÷ 85 × 5, rounded to one decimal. Only documented barriers or restrictive requirements reduce the score. Physical and digital accessibility are excluded from both available points and deductions for every college. Evidence coverage varies and remains visible; the ratings do not certify overall campus accessibility.</p>'
rationale_note = '<p class="rationale-note"><b>Understanding each deduction:</b> “Why points were deducted” explains the accessibility barrier the requirement can create. “A more accessible approach” is a recommendation. Both are editorial assessments; the published policy and its qualifications are shown separately.</p>'

def main_page():
    payload = json.dumps(DATA, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    body = '''<a href="#main" style="position:absolute;left:-9999px;top:0;background:white;padding:8px" onfocus="this.style.left='8px'" onblur="this.style.left='-9999px'">Skip to main content</a>
<header class="topbar"><div class="wrap top-inner"><div class="brand"><span class="brand-mark" aria-hidden="true">↗</span><span>Campus Access <span style="font-weight:550;color:var(--muted)">· Connecticut</span></span></div><div style="display:flex;align-items:center;gap:14px"><div class="top-note">Compare policies. Inspect the evidence.</div><a class="top-cta" href="college-pricing.html">College review requests ↗</a></div></div></header>
<section class="hero"><div class="wrap"><div class="eyebrow">Published accommodation procedures</div><h1>22 Connecticut colleges, rated out of five.</h1><p>Each college starts with the same 85 policy-access points and loses points only for documented barriers or restrictive requirements in the six scored categories. Open a profile to see the calculation, published requirements, exceptions, and supporting sources.</p><div class="hero-stats"><div class="stat"><strong id="collegeTotal">22</strong><span>Colleges listed</span></div><div class="stat"><strong id="ratedTotal">22</strong><span>Colleges with five-star-scale ratings</span></div><div class="stat"><strong id="findingTotal">71</strong><span>Recorded policy findings</span></div><div class="stat"><strong>6</strong><span>Scored policy topics per college</span></div></div><div class="notice"><b>How to read this comparison:</b> Each profile separates recorded deductions, confirmed zero-deduction policies, and unresolved areas. The five-star-scale rating is calculated from the recorded deductions. Evidence gaps remain disclosed alongside it. <a href="rubric.html">Rubric and publication rule</a> · <a href="verification-review.html">Corrections</a> · <a href="six-source-audit.html">Source and retrieval review</a>.</div></div></section>
<main class="main wrap" id="main"><div class="toolbar"><label class="search-wrap"><span aria-hidden="true">⌕</span><input id="search" class="search" type="search" placeholder="Search colleges…" aria-label="Search colleges by name"></label><select id="sort" aria-label="Sort colleges"><option value="name">Sort: college name A–Z</option><option value="deductions">Sort: recorded deductions (research aid)</option><option value="evidence">Sort: categories with evidence</option></select><select id="filter" aria-label="Filter colleges"><option value="all">All colleges</option><option value="changed">Ratings changed in this revision</option><option value="issues">Colleges with excluded deductions</option></select></div><div class="tabs" aria-label="Filter displayed policy findings"><button type="button" class="tab active" data-sev="all" aria-pressed="true">All six categories</button><button type="button" class="tab" data-sev="high" aria-pressed="false">10+ point categories</button><button type="button" class="tab" data-sev="medium" aria-pressed="false">Under 10 points</button></div><p class="evidence-legend">Recorded deduction totals describe the evidence found under an editorial rubric. They are not quality rankings. A category with findings can still be incompletely assessed.</p><noscript><p class="no-js">JavaScript is needed for the interactive college cards. The <a href="audit.html">complete calculation audit</a> and <a href="administrator-proof.html">policy evidence for all 22 colleges</a> work without JavaScript.</p></noscript><div class="layout"><section aria-labelledby="colleges-heading"><div class="results-head"><h2 id="colleges-heading">Colleges in Connecticut</h2><span id="resultsCount" class="results-count">22 colleges</span></div><p class="mobile-detail-hint">Select a college to read its evidence.</p><div id="cards" class="cards"></div><div id="noResults" class="no-results hidden">No colleges match that search.</div></section><section class="panel" id="detailPanel" aria-live="polite" aria-labelledby="detailTitle"><div id="detail" class="detail"></div></section></div></main>
<section class="update-area wrap" id="college-update" aria-labelledby="update-title"><div class="update-shell"><div class="update-head"><div class="eyebrow">For colleges and policy owners</div><h2 id="update-title">Have your accommodation procedures changed?</h2><p>Share the current official policy, its effective date, exceptions, and the student groups or campuses it covers. Corrections depend on evidence. Review fees cannot change the rating publication requirements.</p><p style="margin-top:16px"><a class="top-cta" href="college-pricing.html">Policy review options ↗</a></p></div></div></section><footer class="footer"><div class="wrap footer-inner"><span>Campus Access · Correction review · October 15, 2026</span><span>Provisional policy-burden ratings · Published sources.</span></div></footer>'''
    script = r'''
const $ = id => document.getElementById(id);
const esc = (s='') => String(s).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const a = (url,label='Official source') => `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(label)} ↗</a>`;
const sourceLinks = urls => urls.map((u,i)=>a(u,`Official source ${i+1}`)).join(' · ');
const rationaleNote=/* RATIONALE_NOTE */;
let selectedId = new URLSearchParams(location.search).get('college') || 'ccsu';
if (!colleges.some(c=>c.id===selectedId)) selectedId='ccsu';
let severityFilter='all';
function starMarkup(c){const score=c.policy_burden_rating;return `<span class="star-meter" role="img" aria-label="${score.toFixed(1)} out of 5 stars"><span aria-hidden="true">★★★★★</span><span class="star-fill" aria-hidden="true" style="width:${score*20}%">★★★★★</span></span>`;}
function showCards(){
 const q=$('search').value.trim().toLowerCase(),f=$('filter').value,sort=$('sort').value;
 let list=colleges.filter(c=>(c.name+' '+c.short).toLowerCase().includes(q));
 if(f==='changed') list=list.filter(c=>c.policy_burden_rating!==c.previous_calculation_only_stars);
 if(f==='issues') list=list.filter(c=>(c.excluded_findings||[]).length);
 list.sort((x,y)=>sort==='deductions'?(y.deductions-x.deductions)||x.name.localeCompare(y.name):sort==='evidence'?(y.recorded_evidence_categories-x.recorded_evidence_categories)||x.name.localeCompare(y.name):x.name.localeCompare(y.name));
 $('cards').innerHTML=list.map(c=>`<button type="button" class="college-card ${c.id===selectedId?'selected':''}" data-id="${esc(c.id)}" aria-pressed="${c.id===selectedId}"><div><div class="college-name">${esc(c.name)}</div><div class="college-meta"><span class="status partial">${c.documented_findings} recorded policy findings</span><span style="display:block;margin-top:7px;color:var(--green);font-weight:750">Read policies and sources ↗</span></div></div><div class="card-rating"><div class="rating-numeric">${c.policy_burden_rating.toFixed(1)}<small>/5</small></div>${starMarkup(c)}<div class="rating-qualifier">Provisional policy-burden rating</div><div class="recorded-points">−${c.deductions} pts recorded</div><span class="coverage-badge">${c.recorded_evidence_categories}/6 topics with evidence</span></div></button>`).join('');
 $('resultsCount').textContent=`${list.length} of ${colleges.length} colleges`;
 $('noResults').classList.toggle('hidden',list.length!==0);
 document.querySelectorAll('.college-card').forEach(el=>el.addEventListener('click',()=>{selectedId=el.dataset.id;showCards();showDetail();if(window.innerWidth<900)$('detailPanel').scrollIntoView({behavior:'smooth',block:'start'});}));
}
function renderCategory(k){
 let status=k.items.length?`−${k.deducted} recorded points`:k.evidence_status==='documented_zero'?'0 — automatic academic renewal':'0 counted; assessment open';
 let body=k.items.map(i=>`<div class="rubric-fact"><h4>${esc(i.title)} (−${i.points})</h4><p><b>Published policy:</b> ${esc(i.fact)}</p><p><b>Scope and qualifications:</b> ${esc(i.qualification)}</p><p class="tiny">${esc(i.verification_scope)}</p><div>${sourceLinks(i.links)}</div><div class="barrier-reason"><p><b>Why points were deducted:</b> ${esc(i.barrier_explanation)}</p><p><b>A more accessible approach:</b> ${esc(i.more_accessible_approach)}</p></div></div>`).join('');
 body+=(k.observations||[]).map(i=>`<div class="rubric-fact zero"><h4>${esc(i.title)}</h4><p><b>${i.status==='documented_zero'?'Documented zero under this criterion':'Documented issue — deduction unresolved'}:</b> ${esc(i.fact)}</p><p>${esc(i.qualification)}</p><div>${sourceLinks(i.links)}</div></div>`).join('');
 if(!body) body='<div class="rubric-empty">No specific scored requirement has been established here. This category remains unresolved; it has not been verified barrier-free.</div>';
 if(k.items.length&&!k.review_complete)body+='<p class="rubric-empty">These findings do not complete the category assessment. Other applicable rules, exceptions, and student/campus scopes need comparable review.</p>';
 return `<section class="rubric-category" data-category="${esc(k.id)}"><div class="rubric-category-head"><strong>${esc(k.name)}</strong><span>${status}</span></div>${body}</section>`;
}
function sourceCard(s){
 const st=s.retrieval.retrieval_status,warn=st!=='retrieved';
 const labels={retrieved:'Readable content returned by the research tool',retrieval_failed:'Retrieval failed — reader access not confirmed',intermittent:'Readable through the official embedded link; separate direct retrieval failed',insufficient_text:'Insufficient readable content — not verified',no_usable_result:'No usable result — not verified',not_checked:'Not checked in this pass'};
 const roles={supports_deduction:'Supports a recorded scoring finding',policy:'Additional policy or policy pointer',context:'Background context only',historical:'Historical corroboration; not current-policy proof',duplicate:'Duplicate edition or mirror; not independent evidence'};
 return `<div class="source-card ${warn?'unavailable':''}"><strong>${a(s.url,s.title)}</strong><span class="source-role">${roles[s.kind]}</span><span class="source-status ${warn?'warn':''}">${labels[st]}.${s.retrieval.indexed_official_content_reviewed?' Official indexed text was reviewed; direct access remains unconfirmed.':''}</span>${s.superseded_for?`<span class="source-status warn">${esc(s.superseded_for)}</span>`:''}</div>`;
}
function showDetail(){
 const c=colleges.find(c=>c.id===selectedId)||colleges[0];
 const shown=c.categories.filter(k=>severityFilter==='all'||(severityFilter==='high'&&k.deducted>=10)||(severityFilter==='medium'&&k.deducted>0&&k.deducted<10));
 const notes=(c.review_notes||[]).map(n=>`<div class="coverage-note"><b>${esc(n.title)}:</b> ${esc(n.detail)}<div>${sourceLinks(n.links||[])}</div></div>`).join('');
 const excluded=(c.excluded_findings||[]).map(i=>`<div class="excluded"><b>${esc(i.title)}</b><p>Previous deduction: ${i.previous_points} points. Current deduction: 0.</p><p>${esc(i.decision)}</p><div>${sourceLinks(i.links)}</div></div>`).join('');
 const primary=c.expanded_sources.filter(s=>s.used_for_scoring||s.used_for_observation);
 const rest=c.expanded_sources.filter(s=>!primary.includes(s));
 $('detail').innerHTML=`<div class="detail-top"><div><span class="status partial">Partial policy evidence</span><h2 id="detailTitle">${esc(c.name)}</h2><p class="detail-intro">Published accommodation requirements, scope, exceptions, and open assessment questions.</p></div><div class="rating-box"><div class="big provisional">${c.policy_burden_rating.toFixed(1)} / 5</div>${starMarkup(c)}<div class="outof">Provisional policy-burden rating</div><div class="tiny" style="margin-top:9px">${c.recorded_evidence_categories}/6 topics with evidence<br>${c.completed_categories}/6 category assessments complete</div></div></div><div class="rating-summary"><b>Recorded deductions: ${c.deductions}/85 rubric points.</b> ${c.documented_findings} findings are recorded in ${c.documented_categories} categories. ${c.unresolved_categories} category assessments remain incomplete. Finding a rule does not establish that a category has been fully reviewed. Missing evidence is not penalized; it can affect comparisons.</div><details class="calculation"><summary>How this rating is calculated</summary><p>85 − ${c.deductions} recorded points = ${c.remaining_points}/85. Dividing by 85 and multiplying by 5 gives <b>${c.calculation_only_stars.toFixed(1)}/5</b>, rounded to one decimal using half-up rounding.</p><p>This provisional policy-burden rating uses the recorded deductions under the same editorial rubric. Missing information is not penalized, so evidence coverage and the stated qualifications should be read alongside the stars.</p></details>${notes}${excluded?`<details><summary>Removed or withheld deductions</summary>${excluded}</details>`:''}<div class="detail-section"><div class="section-heading"><h3>Six-category evidence record</h3><a href="rubric.html" class="tiny">Read the rubric ↗</a></div>${rationaleNote}<div class="rubric-grid">${shown.map(renderCategory).join('')||'<p>No recorded deduction categories match this filter. Select All six categories to see open assessments.</p>'}</div></div><div class="detail-section"><h3>Sources supporting findings and observations</h3><p class="evidence-legend">${c.scored_source_count} distinct current-policy URLs support scored findings; ${c.unique_official_source_count} current-policy/background URLs are inventoried and ${c.retrieved_source_count} returned readable content. Source count does not establish independent corroboration or validate a rating. Retrieval is not a live-uptime guarantee.</p><div class="source-grid">${primary.map(sourceCard).join('')}</div><details><summary>Additional policy, background, and historical links</summary><div class="source-grid">${rest.map(sourceCard).join('')}</div></details><p><a href="six-source-audit.html#${esc(c.id)}">Full source inventory and retrieval results ↗</a></p></div><p><a href="administrator-proof.html#${esc(c.id)}">Evidence and administrator questions ↗</a> · <a href="audit.html#${esc(c.id)}">Calculation audit ↗</a></p>`;
}
$('search').addEventListener('input',showCards);
$('filter').addEventListener('change',showCards);
$('sort').addEventListener('change',showCards);
document.querySelectorAll('[data-sev]').forEach(el=>el.addEventListener('click',()=>{severityFilter=el.dataset.sev;document.querySelectorAll('[data-sev]').forEach(b=>{b.classList.toggle('active',b.dataset.sev===severityFilter);b.setAttribute('aria-pressed',String(b.dataset.sev===severityFilter));});showDetail();}));
$('collegeTotal').textContent=colleges.length;
$('ratedTotal').textContent=colleges.filter(c=>Number.isFinite(c.policy_burden_rating)).length;
$('findingTotal').textContent=colleges.reduce((n,c)=>n+c.documented_findings,0);
showCards();showDetail();
'''
    script = script.replace('/* RATIONALE_NOTE */', json.dumps(rationale_note, ensure_ascii=False))
    (ROOT / 'index.html').write_text(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connecticut Colleges · Accommodation Policy Evidence</title><style>{CSS}</style></head><body>{body}<script>const colleges={payload};\n{script}</script></body></html>')

def rubric_page():
    rules = [
        ('Exam booking deadlines',20,'No student booking or ≤2 business days: 0; 3–4: −7; 5–7: −12; 8+: −20. Use the longest supported regular/final-exam tier once. Keep the source’s exact day unit and scope; an unclear deadline stays unresolved.'),
        ('Student administrative workload',20,'Student submits a request for each office-proctored exam: −10. Separate assigned student communication or instructor approval: −5. Additional independent testing-use agreement/form beyond the booking request: −5. Count each task once. Recommendations alone do not establish required coordination. Ordinary initial intake/medical verification is not an extra testing-use task.'),
        ('Flexibility and exceptions',15,'Explicit refusal of disability-related late accommodation requests with no exception or alternative route: −15. Late requests not guaranteed does not establish that condition. A testing-center cutoff alone does not establish refusal of all accommodation alternatives.'),
        ('Medical documentation',10,'Strict blanket recency ≤3 years or strict condition-specific recency ≤1 year: −10. Qualified recency guidance or a recent comprehensive assessment expectation, with alternatives or case-by-case review: −7. Special testing specifications without a recent-evaluation expectation or fixed age: −5. A specific additional-documentation requirement beyond ordinary verification, when no stronger tier applies: −3. Use the highest supported tier once. Generic requests for relevant current-impact information or a right to seek clarification alone do not establish extra testing.'),
        ('Academic accommodation renewals',10,'A repeated student action to activate existing academic accommodations each semester: −10; yearly: −5; confirmed largely automatic academic renewal: 0. Housing-only renewal is outside this criterion and remains separate context. Renewing a notification letter does not establish repeated disability eligibility testing.'),
        ('Appeals and urgent assistance',10,'The disputed accommodation is unavailable during the appeal: −10; an appeal-filing deadline ≤5 business days: −5; 6–10 business days: −3. Use the highest documented tier once. Keep filing deadlines separate from staff response deadlines and preserve the source’s calendar/business-day wording.')]
    rows = ''.join(f'<tr><th scope="row">{e(n)}</th><td>{m}</td><td>{e(r)}</td></tr>' for n,m,r in rules)
    body = rating_note + f'<p class="lede">Version {e(MODEL["version"])}. Six policy categories total 85 points. Physical and digital accessibility are excluded from every college’s calculation, including the available points. The scope and evidence decisions below apply to all 22 institutions. These are editorial policy-workflow weights; they are not a validated measure of overall campus access.</p><div class="table-scroll"><table><thead><tr><th>Criterion</th><th>Maximum deduction</th><th>Rule</th></tr></thead><tbody>{rows}<tr><th>Total</th><th>85</th><td>Never exceed a category cap; never count the same task twice.</td></tr></tbody></table></div>'
    body += '<section class="audit-card"><h2>Missing evidence does not become a good rating</h2><p>The ledger adds only supported deductions. It does not award the remaining points as verified achievement. A completed category needs a current, sufficiently specific policy covering its applicable subcriteria and scopes, including relevant exceptions and conflicting instructions. Only a source-supported barrier or restrictive requirement within a scored category can cost points. Missing information does not create a deduction.</p><p>Every college displays its calculated policy-burden rating, including where category assessment is incomplete. The incomplete-evidence status remains visible. These rubric-based ratings have not been independently validated as overall campus accessibility quality.</p><h3>Reference arithmetic</h3><p>(85 − recorded deductions) ÷ 85 × 5, rounded half up to one decimal, is retained inside each profile and in the audit. This is the formula for every displayed provisional policy-burden rating. Do not normalize scores over only the categories where restrictions were found; doing so introduces another selection bias.</p><h3>Day units</h3><p>Keep the published day unit. A seven-calendar-day week contains five weekdays in an ordinary week; fifteen calendar days contain ten or eleven weekdays, before holidays. A ten-calendar-day appeal window normally spans six to eight weekdays and is placed conservatively in the three-point tier. These are editorial tier comparisons, not changes to university deadlines. When a conversion straddles tiers or institution closures matter, retain the qualification and withhold a stronger unsupported tier.</p></section>'
    body += '<section class="audit-card"><h2>Weights and interpretation</h2><p>Booking and administrative workload account for 40 of the 85 available points. Flexibility accounts for 15; documentation, academic renewal, and appeals each account for 10. Physical and digital accessibility receive no points and no deductions. This emphasizes accommodation procedures. It cannot establish which campus best serves a particular student’s mobility, sensory, learning, health, housing, or program needs. Published policies also do not establish staff performance, implementation reliability, legal compliance, or student outcomes.</p><h3>Source standards</h3><p>Link each factual deduction to its specific official source. Record qualifications, student/program scope, document year, conflicts, and retrieval limitations. A source inventory is not independent corroboration: six different institutional URLs may repeat one rule or provide unrelated context. Historical editions and mirror copies do not establish six independent sources.</p></section>'
    body += '<section class="audit-card"><h2>Why these procedures can be barriers</h2>' + rationale_note + f'<p>{e(MODEL["rationale_note"])}</p><ul class="note-list"><li><b>Exam arrangements:</b> An approved accommodation should be practical to use. Repeated bookings and faculty handoffs add work. A recommended alternative is for the student to share the syllabus once and authorize staff to arrange known exams, obtain updates directly from faculty, and confirm the plan.</li><li><b>Ongoing accommodations:</b> A stable or long-term disability does not necessarily change when a semester ends. A recommended alternative is to carry the approved plan forward, with an easy course-specific opt-in that protects student control over disclosure. Review changed needs or course requirements when necessary.</li><li><b>Documentation and appeals:</b> Extra assessments, short filing windows, and uncertainty during review can add cost, time, and follow-up. The finding explains the particular concern and suggests targeted evidence requests, assistance, flexibility, or interim support.</li></ul><p>These explanations do not add deductions. Scores, category caps, source qualifications, and exceptions remain the same.</p></section>'
    page('rubric.html', 'Policy-workflow rubric and rating publication rule', body)

def audit_pages():
    rows = ''.join(f'<tr><th scope="row"><a href="#{e(c["id"])}">{e(c["name"])}</a></th><td>{c["deductions"]}</td><td>{c["calculation_only_stars"]:.1f}/5</td><td>{c["recorded_evidence_categories"]}/6</td><td>{c["completed_categories"]}/6</td><td>{c["policy_burden_rating"]:.1f}/5</td></tr>' for c in DATA)
    summary = rating_note + rationale_note + '<div class="table-scroll"><table><thead><tr><th>College</th><th>Recorded deduction points</th><th>Calculated /5 value</th><th>Topics with evidence</th><th>Category reviews complete</th><th>Policy-burden rating</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
    detail = ''.join(f'<article id="{e(c["id"])}" class="audit-card"><h2>{e(c["name"])}</h2><p><b>Policy-burden rating: {c["policy_burden_rating"]:.1f}/5.</b> {c["documented_findings"]} scored findings; {c["deductions"]} recorded deduction points. {c["unresolved_categories"]} category assessments remain incomplete.</p>{calculation(c)}{categories(c)}{exclusions(c)}<p><a href="index.html?college={e(c["id"])}">Open interactive profile ↗</a></p></article>' for c in DATA)
    page('audit.html', 'All 22 calculation and evidence records', summary + detail)
    questions = '<div class="questions"><b>Questions for a policy owner:</b><ul><li>Which current document controls, and which students, campuses, and programs does it cover?</li><li>Which actions are required from the student, and which can staff complete?</li><li>What happens with a late request, a changed exam date, or an urgent need?</li><li>What interim arrangements and assistance are available during an appeal?</li><li>What evidence supports any proposed deduction in the six scored policy categories?</li></ul></div>'
    proof = rating_note + rationale_note + '<p class="lede">Published requirements and the editorial point choices are separated below. Each scored requirement includes the barrier it can create and a suggested improvement. These records support questions and corrections; they do not certify every student’s experience.</p>'
    for c in DATA:
        proof += f'<article id="{e(c["id"])}" class="audit-card"><h2>{e(c["name"])}</h2>{notes(c)}{calculation(c)}{categories(c)}{exclusions(c)}{questions}<p><a href="six-source-audit.html#{e(c["id"])}">Source inventory and retrieval limitations ↗</a></p></article>'
    page('administrator-proof.html', 'Published policy evidence and administrator questions', proof)

def correction_page():
    rows = ''.join(f'<tr><th scope="row">{e(s["name"])}</th><td>{s["old_deductions"]}</td><td>{s["new_deductions"]}</td><td>{s["previous_five_point_calculation"]:.1f} → {s["new_five_point_calculation"]:.1f}</td><td>{s["policy_burden_rating"]:.1f}/5</td></tr>' for s in CHANGES['summary'])
    decisions = ''.join(f'<li><b>{e(next(c["name"] for c in DATA if c["id"]==d["college_id"]))}</b>: {e(d["reason"])} <span class="chip neutral">Deduction change: {d["change"]:+d} points</span><div>{links(d["links"])}</div></li>' for d in CHANGES['decisions'])
    body = rating_note + '<p class="lede">This edition fixes inconsistent academic/housing scope, distinguishes recommended from required coordination, adds supported omitted findings, refreshes the current HIU handbook, and aligns the seven-point documentation tier. A change in arithmetic does not establish that campus access improved or worsened.</p><section class="audit-card"><h2>All-college reconciliation</h2><p>The final column shows the published provisional policy-burden rating. The previous column used a 100-point maximum. The current ratings use an 85-point maximum, excluding physical and digital access for every college. Only HIU had a physical deduction to remove; all other retained deductions are unchanged in this scope update.</p><div class="table-scroll"><table><thead><tr><th>College</th><th>Earlier deductions (100-point model)</th><th>Current deductions (85-point model)</th><th>Earlier → current /5 rating</th><th>Policy-burden rating</th></tr></thead><tbody>' + rows + '</tbody></table></div></section><section class="audit-card"><h2>Specific correction decisions</h2><ol class="note-list">' + decisions + '</ol></section><section class="audit-card"><h2>What remains open</h2><p>Source retrieval does not verify every policy interpretation, effective date, campus scope, exception, or actual service outcome. Every college has incomplete categories. Albertus retains an annual-versus-semester conflict, UConn has direct-retrieval limitations, and some policy interpretations still need clarification. Physical and digital access are outside this rating’s scope. These gaps remain visible alongside the provisional policy-burden ratings.</p><p>All pages are generated from the same corrected JSON. Counts distinguish scored findings, categories containing evidence, category reviews completed, and source retrieval. These measures are not interchangeable.</p></section>'
    body += '<section class="audit-card"><h2>Explanation update</h2><p>All 71 scored findings now include “Why points were deducted” and “A more accessible approach.” These additions explain the student workload or access concern and recommend a simpler process. Published facts, sources, all deduction totals, and all 22 ratings are unchanged by this explanation update.</p></section>'
    page('verification-review.html', 'Corrections and unresolved evidence', body)

def source_page():
    failed = [x for x in CHECKS if x['retrieval_status'] != 'retrieved']
    rows = ''.join(f'<tr><th scope="row">{e(c["name"])}</th><td>{c["scored_source_count"]}</td><td>{c["unique_official_source_count"]}</td><td>{c["retrieved_source_count"]}</td><td><a href="#{e(c["id"])}">Inspect sources</a></td></tr>' for c in DATA)
    body = f'<p class="lede">All 158 distinct source URLs in the uploaded inventory were attempted through the research tool. Five current-policy documents/pages were added or refreshed, giving {len(CHECKS)} retrieval records. {len(CHECKS)-len(failed)} returned readable content without a retrieval flag; {len(failed)} have failed, insufficient, or intermittent retrieval. This is a research retrieval check, not a direct HTTP uptime test or guarantee that every reader can open a page.</p><p class="notice"><b>No six-source certification:</b> Different URLs can be context, duplicates, historical material, or pointers. Only the specific policy sources linked to a finding support its deduction. The filename is retained for compatibility with earlier links; a six-source quota is no longer presented as validation.</p><div class="table-scroll"><table><thead><tr><th>College</th><th>Current scoring URLs</th><th>Current policy/context URLs</th><th>Readable retrievals</th><th>Inventory</th></tr></thead><tbody>' + rows + '</tbody></table></div><section class="audit-card"><h2>Retrievals requiring follow-up</h2><p>A failed retrieval is not proof that a URL is permanently broken. These links are visibly flagged wherever they appear in the source inventories. UConn’s indexed official content can support a qualified finding even when direct retrieval fails. The current HIU handbook was readable through its official embedded link but failed a separate direct open; its working handbook landing page is provided.</p><ul>' + ''.join(f'<li>{link(x["url"])} — {STATUS[x["retrieval_status"]]}</li>' for x in failed) + '</ul></section>'
    for c in DATA:
        body += f'<article id="{e(c["id"])}" class="audit-card"><h2>{e(c["name"])}</h2><p>{c["scored_source_count"]} distinct current scoring URLs; {c["retrieved_source_count"]} readable current-policy/context retrievals. These counts do not measure independent reviews or completeness.</p>{inventory(c)}</article>'
    page('six-source-audit.html', 'Official source inventory and retrieval review', body)

def caution_page():
    body = rating_note + '<section class="audit-card"><h2>What is needed for dependable comparisons</h2><ul class="note-list"><li>Apply one clearly defined student and program scope across all institutions.</li><li>Complete all six categories with current evidence, including explicit zero-deduction policies and exceptions.</li><li>Resolve conflicting instructions and verify whether older documents still control.</li><li>Review restrictive requirements, exceptions, and assistance within the six scored policy categories.</li><li>Validate the chosen weights and include implementation or student-experience evidence before claiming overall accessibility quality.</li></ul><p>Missing evidence must remain unresolved. It must not be converted to five-star credit, an invented penalty, or an estimated rating.</p></section>'
    for c in DATA:
        if c.get('review_notes') or c.get('excluded_findings'):
            body += f'<article id="{e(c["id"])}" class="audit-card"><h2>{e(c["name"])}</h2>{notes(c)}{exclusions(c)}</article>'
    page('research-cautions.html', 'Open assessment questions and scoring qualifications', body)

def exports_and_readme():
    with (ROOT / 'official-source-inventory.csv').open('w', newline='') as f:
        out=csv.writer(f);out.writerow(['college','college_id','title','url','role','used_for_scoring','used_for_observation','retrieval_status','review_date','live_http_status'])
        for c in DATA:
            for s in c['expanded_sources']:
                out.writerow([c['name'],c['id'],s['title'],s['url'],s['kind'],s['used_for_scoring'],s['used_for_observation'],s['retrieval']['retrieval_status'],'2026-10-15','not measured'])
    with (ROOT / 'college-ratings.csv').open('w', newline='') as f:
        out=csv.writer(f);out.writerow(['college','rating_out_of_5','recorded_deductions','points_remaining','maximum_points','rating_type'])
        for c in DATA:out.writerow([c['name'],f"{c['policy_burden_rating']:.1f}",c['deductions'],c['remaining_points'],c['score_max_points'],'Provisional policy-burden'])
    with (ROOT / 'evidence-coverage.csv').open('w', newline='') as f:
        out=csv.writer(f);out.writerow(['college','college_id','category','deduction_cap','recorded_deductions','evidence_status','category_review_complete','scored_findings','observation_count'])
        for c in DATA:
            for k in c['categories']:
                out.writerow([c['name'],c['id'],k['name'],k['max'],k['deducted'],k['evidence_status'],k['review_complete'],len(k['items']),len(k['observations'])])
    failed=sum(x['retrieval_status']!='retrieved' for x in CHECKS)
    changed=sum(c['deductions']!=c['previous_deductions'] for c in DATA)
    readme=f'''# Campus Access: corrected policy evidence comparison

Reviewed October 15, 2026. Open **index.html** after extracting the ZIP. All pages run locally; no server or package installation is needed. The pricing/request page is retained from the supplied project.

## What changed

- Added a specific barrier explanation and a more accessible alternative to every one of the 71 scored findings, in profiles and both complete evidence audits. This explanation update changes no ratings, deductions, published policy facts, or sources.
- Recalculated all 22 star ratings on 85 points across six policy categories. Removed HIU’s former five-point physical deduction. The earlier scoring/source corrections remain documented.
- Applied academic-renewal scope consistently; housing-only renewal stays as context.
- Withheld coordination penalties supported only by recommended actions.
- Added supported omitted appeal, communication, and recent-assessment findings.
- Updated Hartford International to its current 2026–2027 handbook.
- Kept source conflicts, limitations, and removed deductions visible.
- Generated every audit page from the same canonical data.

## Ratings and arithmetic

**Every college displays a provisional policy-burden rating out of five stars.**

Each college’s rating is (85 − recorded deductions) / 85 × 5, rounded half up to one decimal. Stars and the numeric value appear on the college cards, in profiles, and in the audits. Missing information is not penalized; evidence coverage and qualifications remain visible. This is a provisional policy-burden rating rather than certification of overall campus accessibility. The six retained category caps total 85; physical and digital accessibility are excluded from both the available points and the deductions; the weights are editorial and have not been independently validated as overall campus accessibility quality.

There are {sum(c['documented_findings'] for c in DATA)} recorded scoring findings. Finding a requirement does not complete its category assessment. The data distinguishes categories with evidence from completed reviews and records a confirmed zero for Western’s largely automatic academic-renewal rule.

## Understanding the explanations

Each scored finding separates the published requirement and source qualifications from **Why points were deducted** and **A more accessible approach**. The latter two are editorial explanations and recommendations, not additional policy claims or findings about actual outcomes. Suggested improvements include staff scheduling known exams from a syllabus with student consent, and continuation of approved supports for stable or long-term disabilities with an easy course-specific opt-in. Student choice about disclosure and changes in needs remain part of those recommendations.

## Sources

All 158 original inventory URLs were attempted with the research tool, plus five refreshed/added official documents or pages. Of {len(CHECKS)} records, {len(CHECKS)-failed} returned readable content without a retrieval flag; {failed} have failed, insufficient, or intermittent retrieval. The current HIU handbook was readable through its official embedded link but failed a separate direct open; its handbook landing page is provided. This is not a direct HTTP uptime test or a guarantee of reader access. Retrieval problems are visibly flagged. Current indexed official UConn text is distinguished from directly retrieved pages. Background links, historical editions, and mirrors do not independently validate a score, and no six-link quota is presented as certification.

## Files

- index.html: original visual structure with corrected evidence-led cards and profiles.
- rubric.html and rubric-data.json: six retained category weights, an 85-point maximum, and explicit evidence/scope rules.
- audit.html: all 22 calculation and category breakdowns.
- administrator-proof.html: claim sources, qualifications, and administrator questions.
- verification-review.html and change-log.json: all-college reconciliation and correction decisions.
- six-source-audit.html: source roles and retrieval review; filename retained for existing links.
- research-cautions.html: unresolved matters and qualifications.
- rating-data.json: canonical college evidence and deductions; provisional five-star-scale ratings are populated for all 22 colleges; the independent comparable-accessibility field remains null.
- official-evidence-sources.json and official-source-inventory.csv: matching source inventories.
- evidence-coverage.csv: all 132 scored college/category rows.
- college-ratings.csv: all 22 displayed ratings and corrected deduction totals.
- source-checks.json: retrieval records, separate from content/claim validation.
- tools/rebuild.py: regenerate the pages and CSVs from the canonical data using Python 3.

## Boundaries

Published policy does not prove every actual accommodation experience, physical route, digital tool, staff action, or legal conclusion. The remaining assessment work is visible; the displayed numerical ratings are the reproducible result of the stated editorial policy-burden rubric.
'''
    (ROOT / 'README.md').write_text(readme)

if __name__ == '__main__':
    main_page()
    rubric_page()
    audit_pages()
    correction_page()
    source_page()
    caution_page()
    exports_and_readme()
    print('Rebuilt the comparison, six supporting evidence pages, README, and CSV exports from canonical JSON.')
